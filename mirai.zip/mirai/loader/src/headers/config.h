#pragma once

#define HTTP_SERVER "167.99.201.146"
#define HTTP_PORT 80

#define TFTP_SERVER "167.99.201.146"
